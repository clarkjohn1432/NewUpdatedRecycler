package com.example.myupdaterecycler;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner courseSpinner, yrSpinner;
    private ImageView imageView;
    private EditText txtFirst, txtLast;
    private Button btnSave, btnCancel;

    private Uri imageUri;
    private String firstName, lastName, course, yr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);

        // Initialize views
        courseSpinner = findViewById(R.id.spinner);
        yrSpinner = findViewById(R.id.spinner2);
        imageView = findViewById(R.id.imageView2);
        txtFirst = findViewById(R.id.editTextText);
        txtLast = findViewById(R.id.editTextText2);
        btnSave = findViewById(R.id.button);
        btnCancel = findViewById(R.id.button2);

        // Image picker
        imageView.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, 100);
        });

        // Spinner listeners
        courseSpinner.setOnItemSelectedListener(this);
        yrSpinner.setOnItemSelectedListener(this);

        // Save button
        btnSave.setOnClickListener(v -> {
            // Get input values
            firstName = txtFirst.getText().toString().trim();
            lastName = txtLast.getText().toString().trim();

            // Check if any field is empty or image not selected
            if (firstName.isEmpty() || lastName.isEmpty()) {
                Toast.makeText(MainActivity2.this, "Please fill up all fields before saving!", Toast.LENGTH_SHORT).show();
                return; // stop here
            }

            // Check if spinners are still at default values
            if (course.equals("Select Course") || yr.equals("Select Year")) {
                Toast.makeText(MainActivity2.this, "Please select a valid course and year!", Toast.LENGTH_SHORT).show();
                return; // stop here
            }

            // If validation passed → send data back
            Intent intent = new Intent();
            intent.putExtra("image", imageUri);
            intent.putExtra("firstname", firstName);
            intent.putExtra("lastname", lastName);
            intent.putExtra("course", course);
            intent.putExtra("yr", yr);

            setResult(RESULT_OK, intent);
            finish();
        });


        // Cancel button
        btnCancel.setOnClickListener(v -> finish());

        // EdgeToEdge padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
            imageUri = data.getData();
            imageView.setImageURI(imageUri);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if (parent == courseSpinner) {
            course = courseSpinner.getItemAtPosition(position).toString();
        } else if (parent == yrSpinner) {
            yr = yrSpinner.getItemAtPosition(position).toString();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // Do nothing
    }
}
